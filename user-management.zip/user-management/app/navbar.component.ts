import { Component } from '@angular/core';

@Component({
    selector:'<navbar></navbar>',
    templateUrl:'app/navbar.component.html'
})

export class NavbarComponent{

}